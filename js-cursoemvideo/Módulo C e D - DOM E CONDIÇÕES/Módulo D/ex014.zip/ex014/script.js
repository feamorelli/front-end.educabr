function carregar() {
    var msg = document.getElementById("msg")
    var img = document.getElementById("imagem")
    var data = new Date()
    var hora = data.getHours()
    msg.innerHTML = `Agora são ${hora} horas.`
    if (hora >= 0 && hora < 12) {
        //bom dia
        img.src = 'imagens/fotomanha.png'
        document.body.style.background = '#d79e18'
        msg.innerHTML += `<br>Bom dia!`
    }
    else if (hora >=12 && hora < 18) {
        //boa tarde
        img.src = 'imagens/fototarde.png'
        document.body.style.background = '#865562'
        msg.innerHTML += `<br>Boa tarde!`
    }
    else {
        //boa noite
        img.src = 'imagens/fotonoite.png'
        document.body.style.background = '#002238'
        msg.innerHTML += `<br>Boa noite!`
        
    }
}
